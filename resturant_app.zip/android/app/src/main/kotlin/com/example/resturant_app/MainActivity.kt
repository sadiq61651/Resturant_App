package com.example.resturant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
